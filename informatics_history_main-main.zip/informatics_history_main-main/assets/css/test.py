a= "King"

b=  "King"
print(a!=b)